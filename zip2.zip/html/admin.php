<!DOCTYPE html>
<?php
	$file = $_GET['file'];
	if(isset($file))
	{
		include($file);
	}
	else
	{
		include(index.html);
	}
?>
<head>
	<title>Xmas Wish Foundation</title>	
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<html>
	<div class="container-contact100">
		<body>
			<h1> WELLCOME TO THE ADMIN AREA</h1>
			<p align="center"> <font size="10">This is the area which alows admins to organize file system quickly, without having to connect to the server directly.
			 If you are here and you are not an admin, there has ben a mistake and we ask you to leave immediately and to report how you got here to our staff.
			 Thank you.</font></p>
		</body>
	</div>
</html>
